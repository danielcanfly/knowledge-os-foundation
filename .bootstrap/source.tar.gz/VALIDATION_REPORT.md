# Validation Report

- Package: `knowledge-os-foundation-contracts-v0.1.0`
- Validation date: 2026-07-02
- Result: PASS

## Executed checks

```text
python scripts/validate_contracts.py
CONTRACT_VALIDATION_PASSED

python -m pytest -q
6 passed

python -m compileall -q scripts tests
PASS
```

## Negative cases verified

- Dirty source manifest is rejected.
- Artifact byte tampering is rejected by SHA-256 validation.
- ACL downgrade from restricted to public is rejected.
- Missing provenance source reference is rejected.
- Broken internal Markdown link is rejected.
- Invalid release and provenance fixtures do not accidentally pass.

## Scope

The tests validate the included fixtures and contract validator. They do not yet validate a production R2 bucket, a live Builder implementation, or a deployed Runtime.
